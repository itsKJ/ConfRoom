package com.meetingrooms.RoomBooking;

public class App {
	
	public static void main(String[] args) {
		
		
		CalendarDay.date();
		Name.getname();
		Rooms.getRoom();
		Slot.slot();
		
		
		String day=CalendarDay.s;
		String name =Name.name;
		int slot =Slot.j;
		int room =Rooms.k;
		
		
		System.out.println("The date is "+day);
		System.out.println("The name is "+name);
		System.out.println("The slot is "+slot);
		System.out.println("Selected room is :"+room );
		
		
	}
}