package com.meetingrooms.RoomBooking;

import java.util.Scanner;

public class Slot {
	static int j;
	static Scanner sc = new Scanner(System.in);
	static public void slot(){
		System.out.println("1. 9 am to 12 pm \n2. 12 pm to 3 pm \n3. 3 pm to 6 pm\n");
		do{
		System.out.println("Enter the required time slot: ");
		j=sc.nextInt();
		if(j>3 || j<1)
			System.out.println("Invalid data");
		}while(j<1 || j>3);
	}
}
