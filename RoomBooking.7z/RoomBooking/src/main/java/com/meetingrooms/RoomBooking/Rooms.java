package com.meetingrooms.RoomBooking;

import java.util.Scanner;

public class Rooms {
	static int k;
	public static void getRoom(){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("1.Room#1\n2.Room#2\n3.Room#3\n4.Room#4\n5.Room#5\n");
		do{
			System.out.println("Enter the required room\n");
			k=sc.nextInt();
			if(k>5 || k<1)
				System.out.println("Invalid data");
		}while(k<1 || k>5);
		
		
	}
}
