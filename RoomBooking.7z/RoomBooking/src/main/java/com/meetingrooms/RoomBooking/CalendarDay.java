package com.meetingrooms.RoomBooking;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class CalendarDay {
	static int i,j;
	static String s;
	static Scanner sc = new Scanner(System.in);
		public static void date()
		{
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			Calendar cal = Calendar.getInstance();
				for(i=1;i<=7;i++)
					{
						cal.add(Calendar.DAY_OF_YEAR, 1);
						System.out.println(i+"."+df.format(cal.getTime()));
				
					}
				do{
			System.out.println("Enter your date: ");
			j=sc.nextInt();
			if(j>7 || j<1)
				System.out.println("Invalid data");
				}while(j<1 || j>7);
			cal = Calendar.getInstance();
			cal.add(Calendar.DAY_OF_YEAR, j);
			s=df.format(cal.getTime());
		}
}