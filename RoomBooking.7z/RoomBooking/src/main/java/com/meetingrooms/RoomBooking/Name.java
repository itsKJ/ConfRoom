package com.meetingrooms.RoomBooking;

import java.util.Scanner;

public class Name {
	static String name;
	static Scanner sc = new Scanner(System.in);
	static public void getname (){
		System.out.println("Enter your team name :");
		name = sc.next();
		
	}
}